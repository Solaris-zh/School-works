PYx = [1,0,0;0,1,0;0,0,1];
C = log2(rank(PYx));